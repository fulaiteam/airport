<template>
    <div class='content'>
        <div class="intrduce">
            <div class="introduce_wrap">
                <div class="intruduce_con">
                    <div class="title">合作伙伴项下企业介绍标题</div>
                </div>
                <div class="companyImg">
                    <img src="../../assets/images/yunExhibitionhall/companyImg.png" alt="">
                </div>
                <div class="business_outline">
                    <div class="bo_con">
                        华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。
                    </div>
                    <div class="bussiness_img">
                        <img src="../../assets/images/cloudTalk/sec.png" alt="">
                        <img src="../../assets/images/cloudTalk/sec.png" alt="">
                    </div>
                    <div class="bo_con">
                        华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。
                    </div>
                    <div class="bussiness_img">
                        <img src="../../assets/images/cloudTalk/sec.png" alt="">
                        <img src="../../assets/images/cloudTalk/sec.png" alt="">
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
               
            }
        },
        methods:{
            
        }
    }
</script>

<style scoped>
.content{
    font-family:Source Han Sans CN;
    margin-bottom: 129px;
}
/* 云展馆企业名称开始 */
.intrduce{
    width: 100%;
    font-family: SourceHanSansCN-Medium;
    display: flex;
    justify-content: center;
    color: #535353;
    font-size: 18px;
}

.intrduce .intruduce_con{
    width: 1095px;
    margin: 0 52.5px;
}
/* 标题 */
.intrduce .intruduce_con .title{
    color: #1577C9;
    font-size: 30px;
    text-align: center;
    font-weight: bold;
    height: 160px;
    line-height: 160px;
}
/* 公司图片 */
.companyImg{
    height: 440px;
    width: 1200px;
    display: flex;
    justify-content: center;
}
.companyImg img{
    width: 870px;
    height: 440px;
}
/* 企业概况 */
.business_outline{
    width: 1200px;
    margin-top: 30px;
}
.business_outline .bo_con{
    color: #666;
    font-size: 18px;
    line-height: 26px;
    margin-top: 60px;
}
.business_outline .bo_img{
    width: 1200px;
    display: flex;
    justify-content: center;
    margin-top: 80px;
}
.bussiness_img{
    display: flex;
    justify-content: flex-start;
    margin-top: 34px;
}
.bussiness_img img{
    height: 310px;
    width: 540px;
    margin-right: 23px;
}
.bussiness_img img:last-child{
    margin: 0;
}
</style>