<template>
    <div>
        <div  class='conten_cccc' >
           <div  class='title' >
               企业相关标题
           </div>
           <div class='img1_area' >
               <img src="../assets/images/index/secondary_img1.png"  class='img1' >
           </div>
           <div  class='text_area1 margin_top76' >

北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。<br>
北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。        
           </div>
           <div  class='img_2area' >
               <img src="../assets/images/index/secondary_img2.png"   class='img2' >
                <img src="../assets/images/index/secondary_img3.png"   class='img2' >
           </div>
            <div  class='text_area1 margin_top60 margin_bottom100' >
               
                                北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。<br>
北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。
                            
           </div>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
.conten_cccc{
    width:1096px;
    margin:0 auto;
}
.title{
    width:100%;
    margin-top:85px;
    height:29px;
    line-height: 29px;
    font-size:30px;
    display: flex;
    justify-content: center;
    font-family:Source Han Sans CN;
    font-weight:bold;
    color:rgba(21,119,201,1);
}
.img1_area{
    width:100%;
    margin-top:53px;
    height:440px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.img1{
    width:870px;
    height:440px;
}
.text_area1{
    width:100%;
    font-size:18px;
    font-family:Source Han Sans CN;
    font-weight:400;
    color:rgba(101,101,101,1);
    line-height:26px;
}
.margin_top76{
     margin-top:76px;
}
.img_2area{
    width:100%;
    height:310px;
    margin-top:58px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.margin_top60{
    margin-top:60px;
}
.margin_bottom100{
    margin-bottom:100px;
}
</style>