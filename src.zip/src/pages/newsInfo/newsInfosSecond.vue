<template>
    <div>
        <div class="tab">
            <div class="content_center">

            </div>
        </div>
        <!--  -->
        <div  class='conten_cccc' >
           <div  class='title' >
               企业相关标题
           </div>
           <div class='img1_area' >
               <img src="../../assets/images/newsInfo/jd.png"  class='img1' >
           </div>
           <div  class='text_area1 margin_top76' >
华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。

           </div>
           <div  class='img_2area' >
               <img src="../../assets/images/index/secondary_img2.png"   class='img2' >
                <img src="../../assets/images/index/secondary_img3.png"   class='img2' >
           </div>
            <div  class='text_area1 margin_top60' >
华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。
                            
           </div>
                      <div  class='img_2area  margin_bottom100' >
               <img src="../../assets/images/index/secondary_img2.png"   class='img2' >
                <img src="../../assets/images/index/secondary_img3.png"   class='img2' >
           </div>
        </div>
        <!--  -->
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style  scoped>
.tab{
    padding: 0;
    margin: 0;
    width: 100%;
    background:#0F1061;
    display: flex;
    justify-content: center;
}
.tab .content_center{
    width: 1200px;
    height: 500px;
    background:url('../../assets/images/congressTopics/tab.png')  no-repeat center;
}
.conten_cccc{
    width:1096px;
    margin:0 auto;
}
.title{
    width:100%;
    margin-top:85px;
    height:29px;
    line-height: 29px;
    font-size:30px;
    display: flex;
    justify-content: center;
    font-family:Source Han Sans CN;
    font-weight:bold;
    color:rgba(21,119,201,1);
}
.img1_area{
    width:100%;
    margin-top:53px;
    height:440px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.img1{
    width:870px;
    height:440px;
}
.text_area1{
    width:100%;
    font-size:18px;
    font-family:Source Han Sans CN;
    font-weight:400;
    color:rgba(101,101,101,1);
    line-height:26px;
}
.margin_top76{
     margin-top:76px;
}
.img_2area{
    width:100%;
    height:310px;
    margin-top:58px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.margin_top60{
    margin-top:60px;
}
.margin_bottom100{
    margin-bottom:100px;
}
</style>