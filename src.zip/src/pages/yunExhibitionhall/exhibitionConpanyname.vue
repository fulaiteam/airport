<template>
    <div class='content'>
        <div class="intrduce">
            <div class="introduce_wrap">
                <div class="intruduce_con">
                    <div class="title">云展馆企业名称</div>
                </div>
                <div class="companyImg">
                    <img src="../../assets/images/yunExhibitionhall/companyImg.png" alt="">
                </div>
                <div class="business_outline">
                    <div class="bo_title">企业概况</div>
                    <div class="bo_con">
                        北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。
                    </div>
                    <div class="bo_img">
                        <img src="../../assets/images/yunExhibitionhall/business_outline.png" alt="">
                    </div>
                </div>
                <div class="business_outline">
                    <div class="bo_title">企业特色</div>
                    <div class="bo_con">
                        北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。北京空港赛瑞安防科技有限公司是首都机场集团公司旗下的北京首都机场航空安保有限公司的全资子公司，是集生产、研发、销售、维护为一体的专业从事民航安防技术管理及相关专业系统集成的科技型企业。
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
               
            }
        },
        methods:{
            
        }
    }
</script>

<style scoped>
.content{
    font-family:Source Han Sans CN;
    margin-bottom: 129px;
}
/* 云展馆企业名称开始 */
.intrduce{
    width: 100%;
    font-family: SourceHanSansCN-Medium;
    display: flex;
    justify-content: center;
    color: #535353;
    font-size: 18px;
}

.intrduce .intruduce_con{
    width: 1095px;
    margin: 0 52.5px;
}
/* 标题 */
.intrduce .intruduce_con .title{
    color: #1577C9;
    font-size: 30px;
    text-align: center;
    font-weight: bold;
    height: 160px;
    line-height: 160px;
}
/* 公司图片 */
.companyImg{
    height: 440px;
    width: 1200px;
    display: flex;
    justify-content: center;
}
.companyImg img{
    width: 870px;
    height: 440px;
}
/* 企业概况 */
.business_outline{
    width: 1200px;
    margin-top: 30px;
}
.business_outline .bo_title{
    text-align: center;
    height: 61px;
    line-height: 61px;
    font-size: 24px;
    color: #666;
    font-weight:500;
    border-bottom:1px solid #666;
}
.business_outline .bo_con{
    color: #666;
    font-size: 18px;
    line-height: 26px;
    margin-top: 17px;
}
.business_outline .bo_img{
    width: 1200px;
    display: flex;
    justify-content: center;
    margin-top: 80px;
}
</style>